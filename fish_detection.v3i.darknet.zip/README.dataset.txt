# Fish Detection > 2023-06-27 5:36pm
https://universe.roboflow.com/sai-shashaank/fish-detection-cnxpt

Provided by a Roboflow user
License: CC BY 4.0

